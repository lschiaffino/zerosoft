zerosoft · kit de marca
Guía completa: https://branding.zerosoft.ai

svg/   logo-dark (tinta, para fondos claros), logo-light (blanco, para fondos oscuros),
       symbol, symbol-light, app-icon y un symbol por producto.
png/   lo mismo a 512 y 1024 px de ancho, fondo transparente.
fonts/ Archivo y JetBrains Mono, SIL Open Font License 1.1.

El nombre se escribe zerosoft, en minúscula.
Área de resguardo: una estación (el diámetro de la o de zero) por lado.
Tamaño mínimo: estación de 15 px, wordmark de 80 px de ancho, símbolo de 16 px.

Neutros: blanco #ffffff, esmalte #f4f4f2, tinta #111111.
Líneas (color de línea para trazos y rellenos; texto: versión AA sobre blanco):
  CRM     línea #7b4dff  oklch(57.8% 0.247 287.9)   texto #7b4dff  oklch(57.8% 0.247 287.9)
  Chat    línea #e23d7f  oklch(62.2% 0.206 1.1)     texto #cf3172  oklch(57.6% 0.199 1.1)
  Agents  línea #ff3b30  oklch(65.4% 0.232 28.7)    texto #dd2720  oklch(57.9% 0.216 28.6)
  Flow    línea #0284c7  oklch(58.8% 0.139 242.0)   texto #0078b7  oklch(54.9% 0.132 242.5)
  Robots  línea #6b7280  oklch(55.1% 0.023 264.4)   texto #6b7280  oklch(55.1% 0.023 264.4)
  Track   línea #f2611d  oklch(67.0% 0.193 41.4)    texto #c84800  oklch(57.1% 0.175 41.2)
  Link    línea #2f6bff  oklch(58.1% 0.229 263.9)   texto #2c66f8  oklch(56.5% 0.227 264.0)
  Docs    línea #c2700a  oklch(62.3% 0.141 61.8)    texto #ab6000  oklch(56.3% 0.131 61.1)
  Notes   línea #e6b400  oklch(79.3% 0.162 88.4)    texto #916c00  oklch(55.4% 0.113 84.8)
  Cal     línea #0e9f6e  oklch(62.2% 0.133 162.3)   texto #008358  oklch(53.9% 0.119 161.6)
  Board   línea #00b8a9  oklch(70.3% 0.124 184.6)   texto #008176  oklch(54.2% 0.096 184.5)

Generado por scripts/brand/build-kit.ts desde lib/brand.ts.
Contacto de prensa: hola@zerosoft.ai
